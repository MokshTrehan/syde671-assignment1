"""Reproduce the optional multi-region / affine audit after python run.py.

Fixed 5x5 grid; even checkerboard cells fit, odd cells validate. All six native
large scans use identical settings. Existing required results are untouched.
"""
from pathlib import Path
import json,time,gc
import numpy as np
from PIL import Image,ImageDraw
from src.alignment import read_plate,make_feature,save_image
from src.affine_audit import local_match,fit_field,score_box,displacement,affine_matrix,compose_affine

ROOT=Path(__file__).resolve().parent
SETTINGS={'grid_fractions':[.20,.35,.50,.65,.80],'patch_side':192,'search_radius':8,
          'fit_cells':'(row+column)%2==0','validation_cells':'(row+column)%2==1',
          'feature':'5-tap-smoothed gradient magnitude','huber_delta_pixels':1.,
          'minimum_training_matches':6,'minimum_validation_matches':6,
          'acceptance':{'median_ncc_gain_vs_best_translation':.002,'minimum_validation_win_fraction':.75,
                        'max_single_patch_ncc_loss':.02,'max_corner_change_from_initial_pixels':12.,
                        'minimum_validation_displacement_rmse_reduction_fraction':.10}}


def audit_channel(ref,mov,initial):
    h,w=ref.shape;half=SETTINGS['patch_side']//2;patches=[]
    for row,fy in enumerate(SETTINGS['grid_fractions']):
        for col,fx in enumerate(SETTINGS['grid_fractions']):
            x=int(round(fx*(w-1)));y=int(round(fy*(h-1)));box=[x-half,y-half,x+half,y+half]
            m=local_match(ref,mov,box,initial,SETTINGS['search_radius'])
            patches.append({'row':row,'column':col,'center':[x-.5,y-.5],'box':box,
                            'split':'fit' if (row+col)%2==0 else 'validation',**m})
    train=[p for p in patches if p['split']=='fit' and p['usable']]
    validation=[p for p in patches if p['split']=='validation' and p['usable']]
    if len(train)<6 or len(validation)<6:return {'patches':patches,'accepted':False,'reason':'insufficient reliable patches'}
    xy=[p['center'] for p in train];sh=[p['shift'] for p in train]
    constant=fit_field(xy,sh,ref.shape,False);affine=fit_field(xy,sh,ref.shape,True)
    original=np.zeros((3,2));original[0]=initial
    # Both translations are scored so geometry is compared against a refitted
    # constant as well as the previously reported global subpixel translation.
    for p in patches:
        p['scores']={k:score_box(ref,mov,p['box'],c) for k,c in [('original',original),('constant',constant),('affine',affine)]}
        x,y=p['center'];p['predictions']={k:displacement(c,np.asarray(x),np.asarray(y),ref.shape).tolist() for k,c in [('original',original),('constant',constant),('affine',affine)]}
    def rmse(key):return float(np.sqrt(np.mean([np.sum((np.array(p['shift'])-p['predictions'][key])**2) for p in validation])))
    gains=np.array([p['scores']['affine']-max(p['scores']['original'],p['scores']['constant']) for p in validation])
    xx=np.array([0,w-1,0,w-1]);yy=np.array([0,0,h-1,h-1])
    corner=float(np.max(np.linalg.norm(displacement(affine-original,xx,yy,ref.shape),axis=1)))
    baseline_rmse=min(rmse('original'),rmse('constant'));reduction=1-rmse('affine')/max(baseline_rmse,1e-12)
    stats={'fit_patches':len(train),'validation_patches':len(validation),
           'local_shift_range_xy':np.ptp(np.array([p['shift'] for p in patches if p['usable']]),axis=0).tolist(),
           'validation_median_ncc_gain':float(np.median(gains)),
           'validation_win_fraction':float(np.mean(gains>0)),
           'validation_worst_ncc_gain':float(gains.min()),'max_corner_change_pixels':corner,
           'validation_shift_rmse':{k:rmse(k) for k in ['original','constant','affine']},
           'validation_rmse_reduction':reduction}
    accepted=bool(np.median(gains)>=.002 and np.mean(gains>0)>=.75 and gains.min()>=-.02 and corner<=12 and reduction>=.10)
    return {'initial_translation':list(initial),'constant_coefficients':constant.tolist(),
            'affine_coefficients':affine.tolist(),'inverse_sampling_matrix':affine_matrix(affine,ref.shape).tolist(),
            'accepted':accepted,'statistics':stats,'patches':patches}


def main():
    records=json.loads((ROOT/'results/metrics.json').read_text());out=ROOT/'results/affine-audit';out.mkdir(exist_ok=True)
    previews=ROOT/'site/dist/images';all_results=[]
    for rec in records:
        if max(rec['channel_shape'])<=512:continue
        start=time.perf_counter();stem=rec['id'];channels=read_plate(ROOT/'data/provided'/f'{stem}.jpg')
        b=make_feature(channels[0],'smooth_edges');result={'id':stem,'shape':rec['channel_shape'],'channels':{}}
        for i,name in [(1,'green'),(2,'red')]:
            feat=make_feature(channels[i],'smooth_edges')
            result['channels'][name]=audit_channel(b,feat,rec['methods']['refined_edges_ncc'][name]);del feat
            print(stem,name,json.dumps({k:v for k,v in result['channels'][name].items() if k in ['accepted','statistics']}),flush=True)
        coeff=[np.asarray(result['channels'][name]['affine_coefficients']) for name in ['green','red']]
        rgb,box=compose_affine(channels,*coeff);result['affine_overlap_box']=list(box)
        save_image(out/f'{stem}-affine.jpg',rgb);save_image(previews/f'{stem}-affine-audit.jpg',rgb,1200)
        del rgb
        result['elapsed_seconds']=round(time.perf_counter()-start,3)
        (out/f'{stem}.json').write_text(json.dumps(result,indent=2)+'\n');all_results.append(result)
        del channels,b;gc.collect()
    (out/'audit.json').write_text(json.dumps({'settings':SETTINGS,'images':all_results},indent=2)+'\n')

if __name__=='__main__':main()
