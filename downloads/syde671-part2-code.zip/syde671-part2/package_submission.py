"""Create source, webpage, and complete-submission ZIPs without transient files."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'
SOURCE=['README.md','requirements.txt','run.py','build_report.py','affine_report.py','audit_affine.py','finish_affine_audit.py','src/affine_audit.py','tests/test_affine_audit.py','export_report.cjs','package_submission.py','src/alignment.py','tests/test_alignment.py','site/dist/style.css']

def zip_files(target,files,empty_provided=False):
    with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=6) as z:
        if empty_provided:z.writestr('syde671-part2/data/provided/','')
        for p in sorted(set(files)):
            z.write(p,'syde671-part2/'+p.relative_to(ROOT).as_posix())
    with ZipFile(target) as z:
        bad=z.testzip()
        if bad:raise RuntimeError(bad)
    return {'file':target.name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}

def main():
    OUT.mkdir(exist_ok=True)
    small=[ROOT/p for p in SOURCE]+list((ROOT/'data/additional').glob('*'))
    downloads=ROOT/'site/dist/downloads';downloads.mkdir(exist_ok=True)
    zip_files(downloads/'syde671-part2-code.zip',small,True)
    for name in ['offsets.csv','metrics.json','environment.json']:
        shutil.copy2(ROOT/'results'/name,downloads/name)
    source=small+list((ROOT/'data/provided').glob('*.jpg'))
    info=[zip_files(OUT/'syde671-part2-code.zip',source)]
    shutil.copy2(ROOT/'results/affine-audit/audit.json',downloads/'affine-audit.json')
    # Portable webpage retains local assets and the small reproducible-code download.
    webpage=[p for p in (ROOT/'site/dist').rglob('*') if p.is_file()]
    info.append(zip_files(OUT/'syde671-part2-webpage.zip',webpage))
    results=[p for p in (ROOT/'results').rglob('*') if p.is_file()]
    complete=source+webpage+results+[OUT/'pdf/syde671-part2-report.pdf']
    if (ROOT/'SUBMISSION.md').exists():complete.append(ROOT/'SUBMISSION.md')
    info.append(zip_files(OUT/'syde671-part2-complete.zip',complete))
    (OUT/'checksums.json').write_text(json.dumps(info,indent=2)+'\n')
    print(json.dumps(info,indent=2))

if __name__=='__main__':main()
