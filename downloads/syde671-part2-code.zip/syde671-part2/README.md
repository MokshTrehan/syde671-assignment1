# SYDE 671 — Assignment 1, Part Two

Reconstruct color images from Prokudin-Gorskii BGR glass plates using explicitly implemented single-scale L2/NCC alignment and a coarse-to-fine pyramid. Optional stages: gradient-based alignment, image-dependent border cropping, damped gray-world white balance, and global percentile contrast.

## Run the experiments

Python 3.10+ is recommended. The recorded run used Python 3.12.14, NumPy 2.3.5, Pillow 12.3.0 on macOS arm64.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run.py
python build_report.py
```

On Windows, activate with `.venv\Scripts\activate` instead.

The full submission includes `data/provided/` (18 supplied scans) and `data/additional/` (3 Library of Congress scans). The smaller website code download omits the course-supplied images: extract the original assignment ZIP and copy its 18 `data/*.jpg` files into `data/provided/` before running. Exclude `__MACOSX` metadata.

All required results use native-resolution inputs. The six large scans are not permanently resized for alignment. At large levels, candidate scoring samples an interior grid to limit runtime; final shifts remain integer native-resolution pixels. The webpage uses resized JPEG previews, while `results/<ID>/` contains full-resolution cropped outputs.

## Main files

- `src/alignment.py`: metrics, search, pyramid, RGB composition and restoration.
- `run.py`: execute all 93 method/image experiments and write images, timings and traces.
- `tests/test_alignment.py`: six known-answer tests.
- `build_report.py`: generate the webpage from actual saved results.
- `site/dist/index.html` and `style.css`: static report, suitable for any static host.
- `results/offsets.csv`: all measured shifts and alignment times.
- `results/metrics.json`: per-image results, level traces and enhancement parameters.
- `results/environment.json`: execution environment and fixed settings.
- `data/additional/sources.json`: original image URLs, record URLs, credit and rights advisory.
- `output/pdf/syde671-part2-report.pdf`: print export of the webpage.

Coordinates are **(dx, dy)**: positive x means right; positive y means down. Green and red are independently shifted relative to blue. Crop boxes use `[x0, y0, x1, y1]`, with exclusive upper bounds.

## Options

```sh
python run.py --only 00458u 31421v
python run.py --single-radius 25
```

The default single-scale radius is 25. The pyramid uses a radius of 15 at the coarsest level and 2 for refinements. Parameters are fixed across images. Running a subset preserves previously computed image records, so use a clean `results/` directory for a completely fresh experiment with changed global settings.

## Results and limitations

Intensity NCC is the main baseline. Visual review found no gross global displacement failure on the 18 supplied scans; some small fringes, motion and damage remain. Single-scale and pyramid L2 fail visibly on 01269v's red channel; its output is intentionally retained and explained. No ground-truth offsets were supplied, so these are visual assessments, not accuracy percentages.

Enhancements are optional renderings. Cropping can mistake scene content for borders or leave narrow residual artifacts. Gray-world assumes a roughly neutral scene and is damped to reduce color casts. Percentile contrast may clip detail. No historical color calibration or restoration of physical damage is claimed.

The assignment examples mention TIFFs and descriptive names, but the supplied archive has 18 numerically named JPEGs. The report follows those actual files. The rubric's `016574` appears to refer to `01657u`, the supplied portrait.

## View and export the report

Open `site/dist/index.html` directly, or serve `site/dist` with `python -m http.server 8000`. No JavaScript is required for the webpage.

The supplied PDF is an export of that same HTML. To re-export, install Playwright (`npm install playwright` and `npx playwright install chromium`) and run `node export_report.cjs`. Alternatively set `PLAYWRIGHT_CHROMIUM_EXECUTABLE` to an existing Chromium/Chrome executable. The script also writes desktop/mobile screenshots and checks for broken images and horizontal overflow. A browser's Print → Save as PDF also works; enable background graphics and use A4.

## Submission

Submit the code ZIP, the PDF, and a grader-accessible webpage link as required by the assignment. A private preview link is not sufficient for a grader unless access is explicitly granted. The complete local bundle includes everything needed to move the static webpage to GitHub Pages or another static host.

## Attribution

Images: Sergei Mikhailovich Prokudin-Gorskii; Prokudin-Gorskii photograph collection, Library of Congress, Prints and Photographs Division. The three additional item records state “No known restrictions on publication.” Details are in `data/additional/sources.json`.

The assignment specification is SYDE 671, Assignment 1, Fall 2026. All reported numbers were computed from the supplied and cited images.
