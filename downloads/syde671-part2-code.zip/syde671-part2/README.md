# SYDE 671 — Assignment 1, Part Two

Reconstruct color images from Prokudin-Gorskii BGR glass plates using explicitly implemented single-scale L2/NCC alignment and a coarse-to-fine pyramid. Improved pyramids standardize each channel at each level, score every interior pixel, and recover truncated local search peaks. Optional stages: smoothed-gradient alignment with fractional-pixel refinement, image-dependent border cropping, damped gray-world white balance, and global percentile contrast.

## Run the experiments

Python 3.10+ is recommended. The recorded run used Python 3.12.14, NumPy 2.3.5, Pillow 12.3.0 on macOS arm64.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run.py
python audit_affine.py
python finish_affine_audit.py
python build_report.py
```

On Windows, activate with `.venv\Scripts\activate` instead.

The full submission includes `data/provided/` (18 supplied scans) and `data/additional/` (3 Library of Congress scans). The smaller website code download omits the course-supplied images: extract the original assignment ZIP and copy its 18 `data/*.jpg` files into `data/provided/` before running. Exclude `__MACOSX` metadata.

All required results use native-resolution inputs. The six large scans are not permanently resized for alignment. The original baselines sample an interior grid at large levels. Improved intensity pyramids score every valid interior pixel and return integer native-resolution shifts; the optional smoothed-edge method adds a bounded fractional-pixel fit and bilinear resampling. The webpage uses resized JPEG previews, while `results/<ID>/` contains full-resolution cropped outputs.

## Main files

- `src/alignment.py`: metrics, search, pyramid, RGB composition and restoration.
- `run.py`: execute all 156 translation method/image experiments and write images, timings and traces.
- `audit_affine.py` and `src/affine_audit.py`: 300 local searches across all six large scans, 12 affine candidate fields, spatial validation and fixed acceptance rules.
- `finish_affine_audit.py`: render accepted per-channel affine corrections and inspection crops.
- `affine_report.py`: report the affine audit, including rejected candidates.
- `results/affine-audit/audit.json`: local measurements, split assignments, model coefficients, validation scores and decisions.
- `tests/test_alignment.py`: 16 known-answer tests across two test modules.
- `build_report.py`: generate the webpage from actual saved results.
- `site/dist/index.html` and `style.css`: static report, suitable for any static host.
- `results/offsets.csv`: all measured shifts and alignment times.
- `results/metrics.json`: per-image results, level traces and enhancement parameters.
- `results/environment.json`: execution environment and fixed settings.
- `data/additional/sources.json`: original image URLs, record URLs, credit and rights advisory.
- `output/pdf/syde671-part2-report.pdf`: print export of the webpage.

Coordinates are **(dx, dy)**: positive x means right; positive y means down. Green and red are independently shifted relative to blue. Crop boxes use `[x0, y0, x1, y1]`, with exclusive upper bounds.

## Options

```sh
python run.py --only 00458u 31421v
python run.py --single-radius 25
python run.py --methods normalized_ncc normalized_l2 refined_edges_ncc
```

The default single-scale radius is 25. All pyramids use a radius of 15 at the coarsest level. Baselines refine within radius 2; improved methods use radius 3 and at most three recentered searches when a finer-level optimum touches a search boundary. The optional edge method fits a parabola to five NCC samples and limits the final correction to half a pixel per axis. Parameters are fixed across images. `--methods` recomputes selected methods while preserving existing others; omit it for a complete run. Running a subset preserves previously computed image records, so use a clean `results/` directory for a completely fresh experiment with changed global settings.

## Results and limitations

Standardized intensity NCC and L2 are the primary improved results. They select identical offsets on all 21 scans, although agreement is not proof of accuracy. Visual review found no gross global displacement failure in the improved results; some small fringes and scan damage remain. Standardization resolves the large raw-L2 displacement error on mural 01269v. The original single-scale and pyramid L2 failures are retained for comparison. Native-resolution detail crops compare the original NCC, improved intensity NCC, and optional refined-edge method at the same blue-reference coordinates. No ground-truth offsets were supplied, so these are visual assessments, not accuracy percentages.

Enhancements are optional renderings. Cropping can mistake scene content for borders or leave narrow residual artifacts. Gray-world assumes a roughly neutral scene and is damped to reduce color casts. Percentile contrast may clip detail. No historical color calibration or restoration of physical damage is claimed.

The assignment examples mention TIFFs and descriptive names, but the supplied archive has 18 numerically named JPEGs. The report follows those actual files. The rubric's `016574` appears to refer to `01657u`, the supplied portrait.

## Optional multi-region / affine audit

The fixed 5×5 grid uses 192×192 native-pixel patches and a ±8 local search around each existing smoothed-edge translation. Thirteen checkerboard locations fit an affine displacement field or a constant-translation control; twelve spatially separate locations validate them. Weak and boundary matches are excluded under documented rules. Coefficients use a Huber-weighted least-squares fit. Selection requires agreement gains, limited individual-region losses, reduced disagreement with local shift estimates, and a bounded corner change. Validation is used for model selection, so it is not an independent test-set accuracy estimate.

Only three of twelve channel candidates pass: green and red on metalwork `01047u`, and red on timber `01007a`. The optional `*-selected.jpg` outputs use those accepted fields and retain translation for rejected channels. The metalwork shows a clear reduction in color separation across multiple structures; the timber result is modest and retains green-channel fringes. All other affine candidates remain experimental. Original required outputs and the earlier restoration sequence are preserved. The audit uses original channel intensities with a single bilinear resampling and conservative valid-support cropping; it applies no color correction. Native-pixel close-ups and grid maps are included in the report.

Run the two audit scripts after the full `run.py` experiment and before `build_report.py`. They use only the existing NumPy/Pillow dependencies. Five additional synthetic tests verify affine coordinate direction, sampling bounds, robust fitting, composition and known-scene recovery. No third-party registration or warping routine is used.

## View and export the report

Open `site/dist/index.html` directly, or serve `site/dist` with `python -m http.server 8000`. No JavaScript is required for the webpage.

The supplied PDF is an export of that same HTML. To re-export, install Playwright (`npm install playwright` and `npx playwright install chromium`) and run `node export_report.cjs`. Alternatively set `PLAYWRIGHT_CHROMIUM_EXECUTABLE` to an existing Chromium/Chrome executable. The script also writes desktop/mobile screenshots and checks for broken images and horizontal overflow. A browser's Print → Save as PDF also works; enable background graphics and use A4.

## Submission

Submit the code ZIP, the PDF, and a grader-accessible webpage link as required by the assignment. A private preview link is not sufficient for a grader unless access is explicitly granted. The complete local bundle includes everything needed to move the static webpage to GitHub Pages or another static host.

## Attribution

Images: Sergei Mikhailovich Prokudin-Gorskii; Prokudin-Gorskii photograph collection, Library of Congress, Prints and Photographs Division. The three additional item records state “No known restrictions on publication.” Details are in `data/additional/sources.json`.

The assignment specification is SYDE 671, Assignment 1, Fall 2026. All reported numbers were computed from the supplied and cited images.
