"""Reproduce all image experiments: python run.py [--only STEM ...]."""
from pathlib import Path
import argparse,csv,gc,json,platform,time
import numpy as np
from PIL import __version__ as pillow_version
from src.alignment import read_plate,align,compose,detect_crop,white_balance,contrast,save_image,pyramid

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only',nargs='+',help='Process selected image stems')
    parser.add_argument('--single-radius',type=int,default=25,help='Single-scale search radius in pixels')
    args=parser.parse_args()
    out=ROOT/'results';out.mkdir(exist_ok=True)
    previews=ROOT/'site/dist/images';previews.mkdir(parents=True,exist_ok=True)
    records=[]
    for group in ('provided','additional'):
        for path in sorted((ROOT/'data'/group).glob('*.jpg')):
            if args.only and path.stem not in args.only:continue
            channels=read_plate(path);b,g,r=channels
            stem=path.stem;folder=out/stem;folder.mkdir(exist_ok=True)
            rgb,_=compose(channels,crop_overlap=False)
            save_image(previews/f'{stem}-unaligned.jpg',rgb,1000)
            del rgb
            record={'id':stem,'group':group,'channel_shape':list(b.shape),'methods':{}}
            methods=[('pyramid_ncc','ncc',True,'intensity'),('pyramid_l2','l2',True,'intensity'),
                     ('edges_ncc','ncc',True,'edges')]
            if max(b.shape)<=512:
                methods=[('single_ncc','ncc',False,'intensity'),('single_l2','l2',False,'intensity')]+methods
            for name,metric,multi,feature in methods:
                start=time.perf_counter()
                radius=15 if multi else args.single_radius
                gs,gt=align(b,g,metric,multi,feature,radius=radius)
                rs,rt=align(b,r,metric,multi,feature,radius=radius)
                elapsed=time.perf_counter()-start
                rgb,overlap=compose(channels,gs,rs)
                save_image(folder/f'{name}.jpg',rgb)
                save_image(previews/f'{stem}-{name}.jpg',rgb,1200)
                result={'green':list(gs),'red':list(rs),'alignment_seconds':round(elapsed,4),
                        'overlap_box':list(overlap),'trace_green':gt,'trace_red':rt}
                if name=='edges_ncc':
                    cropped,box=detect_crop(rgb)
                    balanced,gains=white_balance(cropped)
                    enhanced,stretch=contrast(balanced)
                    for label,im in [('cropped',cropped),('balanced',balanced),('enhanced',enhanced)]:
                        save_image(previews/f'{stem}-{label}.jpg',im,1200)
                    save_image(folder/'enhanced.jpg',enhanced)
                    record['enhancements']={'crop_box_in_overlap':list(box),'gray_world_gains_rgb':gains,
                                            'contrast_percentiles':stretch,
                                            'retained_area_fraction':round(cropped.shape[0]*cropped.shape[1]/(b.size),4)}
                    del cropped,balanced,enhanced
                record['methods'][name]=result
                del rgb
                print(f'{stem:8s} {name:12s} G={str(gs):12s} R={str(rs):12s} {elapsed:.2f}s',flush=True)
            # Save true algorithm intermediate levels for three specified experiments.
            if stem in ('00458u','31421v','01657u'):
                levels=[pyramid(a) for a in channels]
                traces=record['methods']['pyramid_ncc']
                for gt,rt in zip(traces['trace_green'],traces['trace_red']):
                    level=gt['level']
                    rgb,_=compose(tuple(p[level] for p in levels),gt['shift'],rt['shift'])
                    save_image(previews/f'{stem}-level-{level}.jpg',rgb,800)
                del levels,rgb
            (folder/'metrics.json').write_text(json.dumps(record,indent=2)+'\n')
            records.append(record)
            del channels,b,g,r
            gc.collect()
    # Include existing records when --only is used.
    records=[json.loads(p.read_text()) for p in sorted(out.glob('*/metrics.json'))]
    (out/'metrics.json').write_text(json.dumps(records,indent=2)+'\n')
    with (out/'offsets.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['image','group','method','green_dx','green_dy','red_dx','red_dy','alignment_seconds'])
        for rec in records:
            for name,m in rec['methods'].items():
                writer.writerow([rec['id'],rec['group'],name,*m['green'],*m['red'],m['alignment_seconds']])
    environment={'python':platform.python_version(),'platform':platform.platform(),'processor':platform.machine(),
                 'numpy':np.__version__,'pillow':pillow_version,'parameters':{'single_radius':args.single_radius,'coarse_radius':15,'refine_radius':2,
                 'pyramid_max_coarse_side':256,'score_border_fraction':.12,'score_max_side':512,
                 'crop_max_fraction':.12,'contrast_percentiles':[1,99]}}
    (out/'environment.json').write_text(json.dumps(environment,indent=2)+'\n')


if __name__=='__main__':main()
