import unittest
import numpy as np
from src.alignment import align,compose,downsample,detect_crop,white_balance,contrast


class AlignmentTests(unittest.TestCase):
    def test_translation_sign_and_metrics(self):
        rng=np.random.default_rng(671)
        ref=rng.random((130,150),dtype=np.float32)
        mov=np.roll(ref,(5,-9),(0,1))
        for metric in ('ncc','l2'):
            shift,_=align(ref,mov,metric,multiscale=False)
            self.assertEqual(shift,(9,-5))

    def test_pyramid_large_shift_odd_dimensions(self):
        rng=np.random.default_rng(67)
        a=rng.random((705,811),dtype=np.float32)
        # Correlated texture remains recognizable after downsampling.
        for _ in range(5):a=(a+np.roll(a,1,0)+np.roll(a,-1,0)+np.roll(a,1,1)+np.roll(a,-1,1))/5
        moving=np.roll(a,(-29,47),(0,1))
        for metric in ('ncc','l2'):
            shift,_=align(a,moving,metric)
            self.assertEqual(shift,(-47,29))

    def test_ncc_gain_invariance(self):
        rng=np.random.default_rng(6)
        a=rng.random((140,160),dtype=np.float32)*.5
        self.assertEqual(align(a,np.roll(a*1.8,(3,7),(0,1)),multiscale=False)[0],(-7,-3))

    def test_overlap_has_no_wrapped_pixels(self):
        a=np.random.default_rng(7).random((60,70),dtype=np.float32)
        channels=(a,np.roll(a,(3,-4),(0,1)),np.roll(a,(-2,6),(0,1)))
        rgb,box=compose(channels,(4,-3),(-6,2))
        np.testing.assert_allclose(rgb[:,:,0],rgb[:,:,1])
        np.testing.assert_allclose(rgb[:,:,1],rgb[:,:,2])
        self.assertEqual(box,(4,2,64,57))

    def test_downsample_constant_and_odd_shape(self):
        out=downsample(np.ones((51,63),np.float32))
        self.assertEqual(out.shape,(26,32))
        np.testing.assert_allclose(out,1)

    def test_detected_border_and_flat_restoration(self):
        a=np.full((100,120,3),.5,np.float32)
        a[:7]=0;a[-6:]=1;a[:,:8]=0;a[:,-9:]=1
        cropped,box=detect_crop(a)
        self.assertEqual(box,(8,7,111,94))
        np.testing.assert_allclose(cropped,.5)
        balanced,gains=white_balance(cropped)
        enhanced,_=contrast(balanced)
        self.assertTrue(np.isfinite(enhanced).all())


if __name__=='__main__':unittest.main()
