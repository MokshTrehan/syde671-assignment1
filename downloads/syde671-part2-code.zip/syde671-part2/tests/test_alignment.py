import unittest
import numpy as np
from src.alignment import align,compose,downsample,detect_crop,white_balance,contrast,standardize,refine_integer


class AlignmentTests(unittest.TestCase):
    def test_translation_sign_and_metrics(self):
        rng=np.random.default_rng(671)
        ref=rng.random((130,150),dtype=np.float32)
        mov=np.roll(ref,(5,-9),(0,1))
        for metric in ('ncc','l2'):
            shift,_=align(ref,mov,metric,multiscale=False)
            self.assertEqual(shift,(9,-5))

    def test_pyramid_large_shift_odd_dimensions(self):
        rng=np.random.default_rng(67)
        a=rng.random((705,811),dtype=np.float32)
        # Correlated texture remains recognizable after downsampling.
        for _ in range(5):a=(a+np.roll(a,1,0)+np.roll(a,-1,0)+np.roll(a,1,1)+np.roll(a,-1,1))/5
        moving=np.roll(a,(-29,47),(0,1))
        for metric in ('ncc','l2'):
            shift,_=align(a,moving,metric)
            self.assertEqual(shift,(-47,29))

    def test_ncc_gain_invariance(self):
        rng=np.random.default_rng(6)
        a=rng.random((140,160),dtype=np.float32)*.5
        self.assertEqual(align(a,np.roll(a*1.8,(3,7),(0,1)),multiscale=False)[0],(-7,-3))

    def test_overlap_has_no_wrapped_pixels(self):
        a=np.random.default_rng(7).random((60,70),dtype=np.float32)
        channels=(a,np.roll(a,(3,-4),(0,1)),np.roll(a,(-2,6),(0,1)))
        rgb,box=compose(channels,(4,-3),(-6,2))
        np.testing.assert_allclose(rgb[:,:,0],rgb[:,:,1])
        np.testing.assert_allclose(rgb[:,:,1],rgb[:,:,2])
        self.assertEqual(box,(4,2,64,57))

    def test_downsample_constant_and_odd_shape(self):
        out=downsample(np.ones((51,63),np.float32))
        self.assertEqual(out.shape,(26,32))
        np.testing.assert_allclose(out,1)

    def test_detected_border_and_flat_restoration(self):
        a=np.full((100,120,3),.5,np.float32)
        a[:7]=0;a[-6:]=1;a[:,:8]=0;a[:,-9:]=1
        cropped,box=detect_crop(a)
        self.assertEqual(box,(8,7,111,94))
        np.testing.assert_allclose(cropped,.5)
        balanced,gains=white_balance(cropped)
        enhanced,_=contrast(balanced)
        self.assertTrue(np.isfinite(enhanced).all())

    def test_standardized_alignment_gain_and_offset(self):
        a=np.random.default_rng(6710).random((271,305),dtype=np.float32)
        moving=np.roll(.6*a+.25,(8,-12),(0,1))
        for metric in ('ncc','l2'):
            result,_=align(a,moving,metric,feature='normalized',max_score_side=None,refine_radius=3)
            self.assertEqual(result,(12,-8))

    def test_subpixel_known_continuous_translation(self):
        yy,xx=np.mgrid[:265,:301].astype(np.float32)
        def scene(x,y):
            return .5+.15*np.sin(.055*x)+.12*np.cos(.071*y)+.10*np.sin(.041*x+.067*y)+.04*np.cos(.12*x-.034*y)
        a=scene(xx,yy);moving=scene(xx-3.35,yy+2.2)
        result,_=align(a,moving,feature='smooth_edges',max_score_side=None,refine_radius=3,subpixel=True)
        np.testing.assert_allclose(result,(-3.35,2.2),atol=.12)

    def test_fractional_overlap_no_wrapping(self):
        yy,xx=np.mgrid[:60,:70].astype(np.float32)
        def ramp(x,y):return (x+2*y)/200
        channels=(ramp(xx,yy),ramp(xx-4.2,yy+3.4),ramp(xx+2.7,yy-1.6))
        rgb,box=compose(channels,(-4.2,3.4),(2.7,-1.6))
        self.assertEqual(box,(3,4,65,58))
        np.testing.assert_allclose(rgb[:,:,0],rgb[:,:,2],atol=2e-7)
        np.testing.assert_allclose(rgb[:,:,1],rgb[:,:,2],atol=2e-7)

    def test_standardize_flat_channel(self):
        np.testing.assert_array_equal(standardize(np.ones((70,90),np.float32)),0)

    def test_boundary_search_recovers_truncated_peak(self):
        yy,xx=np.mgrid[:150,:170].astype(np.float32)
        a=np.exp(-((xx-80)**2+(yy-75)**2)/350).astype(np.float32)
        moving=np.roll(a,(0,-8),(0,1))
        shift,_,_,centers=refine_integer(a,moving,'ncc',(0,0),3,None,3)
        self.assertEqual(shift,(8,0))
        self.assertGreater(len(centers),1)


if __name__=='__main__':unittest.main()
