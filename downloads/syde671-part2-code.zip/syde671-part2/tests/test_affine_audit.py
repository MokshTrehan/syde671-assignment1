import unittest
import numpy as np
from src.affine_audit import bilinear,design,displacement,fit_field,affine_matrix,compose_affine,local_match


class AffineAuditTests(unittest.TestCase):
    def test_bilinear_ramp_and_invalid_coordinates(self):
        y,x=np.mgrid[:30,:40].astype(float);a=.02*x+.03*y
        np.testing.assert_allclose(bilinear(a,x[2:-2,2:-2]+.3,y[2:-2,2:-2]+.7),
                                   a[2:-2,2:-2]+.02*.3+.03*.7,atol=1e-7)
        with self.assertRaises(ValueError):bilinear(a,np.array([-0.1]),np.array([5.]))

    def test_inverse_matrix_direction(self):
        c=np.array([[4.,-3.],[2.,1.],[-1.,3.]])
        points=np.array([[50.,90.],[200.,100.],[300.,250.]])
        q=points-displacement(c,points[:,0],points[:,1],(301,401))
        np.testing.assert_allclose(np.c_[points,np.ones(3)]@affine_matrix(c,(301,401)).T,q)

    def test_robust_field_with_one_bad_match(self):
        xx,yy=np.meshgrid(np.linspace(80,320,5),np.linspace(60,240,5))
        xy=np.c_[xx.ravel(),yy.ravel()];truth=np.array([[4.,-3.],[3.,-2.],[1.,2.5]])
        shifts=design(xy[:,0],xy[:,1],(301,401))@truth;shifts[0]+=[18.,-15.]
        fit=fit_field(xy,shifts,(301,401))
        pred=design(xy[:,0],xy[:,1],(301,401))@(fit-truth)
        self.assertLess(np.max(np.linalg.norm(pred,axis=1)),.35)

    def test_affine_composition_analytic_scene(self):
        shape=(151,181);y,x=np.mgrid[:shape[0],:shape[1]].astype(float)
        def scene(x,y):return .1+.002*x+.003*y
        coeffs=[np.array([[4.3,-3.2],[2.,-.8],[.4,1.5]]),np.array([[-3.,2.1],[-1.,1.],[.5,-1.5]])]
        channels=[scene(x,y).astype(np.float32)]
        for c in coeffs:
            M=affine_matrix(c,shape);inv=np.linalg.inv(M[:,:2]);p=(np.stack((x,y),axis=-1)-M[:,2])@inv.T
            channels.append(scene(p[:,:,0],p[:,:,1]).astype(np.float32))
        rgb,box=compose_affine(channels,*coeffs)
        np.testing.assert_allclose(rgb[:,:,0],rgb[:,:,2],atol=2e-7)
        np.testing.assert_allclose(rgb[:,:,1],rgb[:,:,2],atol=2e-7)
        self.assertGreater(box[0],0);self.assertLess(box[2],shape[1])

    def test_local_matches_recover_known_affine_scene(self):
        shape=(601,701);y,x=np.mgrid[:shape[0],:shape[1]].astype(float)
        rng=np.random.default_rng(1671)
        freq=rng.uniform(-.13,.13,(20,2));phase=rng.uniform(0,2*np.pi,20)
        def scene(x,y):
            a=np.full_like(x,.6)
            for (fx,fy),p in zip(freq,phase):a+=.018*np.cos(fx*x+fy*y+p)
            return a.astype(np.float32)
        truth=np.array([[5.3,-3.2],[3.,-2.],[1.,2.5]])
        M=affine_matrix(truth,shape);inv=np.linalg.inv(M[:,:2]);p=(np.stack((x,y),axis=-1)-M[:,2])@inv.T
        ref=scene(x,y);mov=scene(p[:,:,0],p[:,:,1]);positions=[];shifts=[]
        for row,fy in enumerate([.2,.35,.5,.65,.8]):
            for col,fx in enumerate([.2,.35,.5,.65,.8]):
                if (row+col)%2:continue
                cx=int(fx*(shape[1]-1));cy=int(fy*(shape[0]-1))
                m=local_match(ref,mov,[cx-40,cy-40,cx+40,cy+40],truth[0],radius=5)
                self.assertTrue(m['usable']);positions.append([cx-.5,cy-.5]);shifts.append(m['shift'])
        fitted=fit_field(positions,shifts,shape)
        held=np.array([[.35*700,.2*600],[.5*700,.35*600],[.8*700,.65*600]])
        error=design(held[:,0],held[:,1],shape)@(fitted-truth)
        self.assertLess(np.max(np.linalg.norm(error,axis=1)),.35)

if __name__=='__main__':unittest.main()
