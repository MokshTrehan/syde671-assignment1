"""Measured optional affine-audit sections for the static assignment report."""
from pathlib import Path
import json,html
ROOT=Path(__file__).resolve().parent


def build_affine_sections(picture,table,section):
    audit=json.loads((ROOT/'results/affine-audit/audit.json').read_text());by={r['id']:r for r in audit['images']}
    intro='''<p>The close-ups suggest that one translation may not align every part of a large scan. This optional experiment checks all six large supplied images with the same 25-region grid. It does not replace the required intensity L2/NCC experiments.</p><h3>Local measurements and spatial validation</h3><p>Place 192 × 192 native-pixel patches at every combination of 20%, 35%, 50%, 65%, and 80% of the blue channel’s width and height. Match smoothed gradient magnitudes with full-pixel NCC in a ±8-pixel window around the existing subpixel translation, then fit a bounded subpixel peak. Reject local matches at the search boundary, below NCC 0.25, or with reference standard deviation below 10⁻⁵. A rejected match is an uncertain measurement, not evidence of no motion.</p><p>A checkerboard split assigns 13 patches to fitting and 12 to validation before exclusions. Fit only the first set: both a constant translation and a six-parameter affine displacement field use ten Huber reweighting iterations with a one-pixel residual threshold. The field is <code>d(x,y) = c₀ + cₓ[x/(W−1)−½] + cᵧ[y/(H−1)−½]</code>; sample the moving channel at <code>(x,y) − d(x,y)</code>. It permits rotation, scale and shear as well as translation.</p><div class="audit-maps">'''+picture('01047u','audit-grid','Metalwork: yellow = fit; cyan = validation')+picture('01007a','audit-grid','Timber: the same grid and split')+'''</div><h3>Conservative selection rule</h3><p>Require at least six usable patches in each split. On validation patches, the affine candidate must beat the better of the original and refitted translations by a median NCC of at least 0.002, win on at least 75% of patches, and lose no more than 0.02 on any patch. Its displacement RMSE against local match estimates must fall by at least 10%, and its maximum change from the original translation at the four image corners must not exceed 12 pixels. These fixed criteria were set before inspecting the audit results.</p><p class="caption">Validation patches do not fit coefficients, but do select the final model: these are model-selection results, not an independent test-set accuracy estimate. Local shifts and gradient NCC are imperfect proxies, not ground truth. No model is refitted after selection. Rejected channels retain their original subpixel translation.</p>'''
    content=section('06D','Multi-region alignment audit',intro,'affine-audit')
    rows=[]
    for r in audit['images']:
        for name,c in r['channels'].items():
            s=c['statistics'];v=s['validation_shift_rmse'];old=min(v['original'],v['constant'])
            reasons=[]
            if s['validation_median_ncc_gain']<.002:reasons.append('median gain')
            if s['validation_win_fraction']<.75:reasons.append('win rate')
            if s['validation_worst_ncc_gain']<-.02:reasons.append('local loss')
            if s['validation_rmse_reduction']<.10:reasons.append('shift error')
            if s['max_corner_change_pixels']>12:reasons.append('corner bound')
            rows.append([r['id']+' / '+name[0].upper(),f'{s["fit_patches"]} / {s["validation_patches"]}',
                ' / '.join(f'{v:.1f}' for v in s['local_shift_range_xy']),f'{s["validation_median_ncc_gain"]:+.3f}',
                f'{old:.2f} → {v["affine"]:.2f}', 'Use affine' if c['accepted'] else 'Keep translation: '+', '.join(reasons)])
    body='''<p>Local shift ranges span several pixels even after the global translation. This motivates testing geometry, but can also reflect ambiguous texture, channel-dependent appearance or local movement. Each row below compares one affine candidate with both translation controls.</p>'''+table(['Scan / channel','Fit / val.','Local range<br>x / y (px)','Median ΔNCC','Shift RMSE<br>before → after (px)','Selection'],rows)+'''<p class="caption">Counts exclude unusable local matches. Local range covers all usable grid patches. ΔNCC uses the better translation score separately on each validation patch. “Before” RMSE is the better whole-validation-set translation RMSE; “after” uses the affine field. RMSE measures agreement with estimated local shifts, not registration accuracy. Full patch scores, exclusions, coefficients and sampling matrices are in the downloadable audit JSON.</p><h3>What the checks support</h3><p><strong>01047u:</strong> both channels pass. The metalwork close-ups show reduced colored doubling along several independent structures. <strong>01007a:</strong> red passes, while green fails the displacement-error and corner-change checks; use a red-only affine correction. The portrait’s red candidate loses substantial local agreement and is rejected.</p><p>Some other candidates visibly improve parts of their images but fail the fixed limits: the train and interior scan 01725u exceed the corner-change bound; 01861a has individual validation-patch losses beyond the allowed threshold. These are retained as experimental candidates, not silently promoted to selected outputs. A selection failure does not prove that every part of an image became worse.</p><p>The selected outputs resample original intensities once with bilinear interpolation and crop to a conservatively valid rectangle. They apply no white balance or contrast. The required gallery and earlier optional restoration sequence remain separate, clearly identified experiments.</p><div class="downloads"><a href="downloads/affine-audit.json">Download all affine-audit measurements</a></div>'''
    content+=section('06E','Affine validation results',body,'affine-validation')
    notes={
      '01047u':[
       'The bright green/magenta doubling around the embossed ornament and oval outline is reduced. Fine detail remains visible; this is more than a change in global color balance.',
       'The metallic rays and vertical border show less lateral color separation. Small residual colored edges remain, so the affine model is not an exact local correction.',
       'The chain and curved vessel show the clearest reduction in red/green separation. Specular highlights still differ between channels.'],
      '01007a':[
       'The red-channel correction reduces some red/cyan separation near the posts and tree line. Green remains a translation, and faces are not evidence of exact alignment because exposures may differ locally.',
       'The central joints retain visible fine colored edges. The red-only correction offers a modest improvement rather than a complete repair of the structure.',
       'Some timber and textile edges improve, but the remaining green-channel mismatch is visible. The rejected full-affine candidate is available for comparison; it was not selected simply because some regions look cleaner.']}
    for stem,title,kicker in [('01047u','Metalwork: multi-region comparison','06F'),('01007a','Timber: a cautious partial correction','06G')]:
        rec=by[stem];names=' and '.join(rec['selected_affine_channels'])
        body=f'<p>Selected affine channels: <strong>{names}</strong>. Each pair shows the identical 384 × 384 native-pixel rectangle in blue-reference coordinates. Display regions are chosen to inspect identifiable features and do not affect fitting or selection. Click a crop to open its native pixels.</p>'
        for region,note in zip(rec['display_regions'],notes[stem]):
            i=region['index'];box=region['blue_reference_box']
            body+=f'<article class="audit-detail"><h3>{i}. {html.escape(region["label"])}</h3><div class="audit-pair">'+picture(stem,f'audit-{i}-translation','Before: smoothed-edge subpixel translation')+picture(stem,f'audit-{i}-selected','After: audit-selected optional correction')+f'</div><p class="caption">{note} Blue-reference box: {box}.</p></article>'
        body+=f'<p class="caption"><a href="images/{stem}-affine-selected.jpg">Selected full-scene preview</a> · <a href="images/{stem}-affine-audit.jpg">Unrestricted affine candidate preview</a>. Neither preview is evidence of ground-truth accuracy.</p>'
        content+=section(kicker,title,body,'affine-'+stem)
    return content
