"""Translation alignment and conservative restoration of stacked BGR plates.

Only NumPy and Pillow are used. No registration or pyramid library is called.
Coordinates exposed to users are (dx, dy): positive means right and down.
"""
from __future__ import annotations
import math
import numpy as np
from PIL import Image


def read_plate(path):
    with Image.open(path) as im:
        plate = np.asarray(im.convert('L'), dtype=np.float32) / 255.0
    h = plate.shape[0] // 3
    return tuple(plate[i*h:(i+1)*h].copy() for i in range(3))


def downsample(a):
    """Separable 5-tap binomial low-pass followed by factor-two decimation."""
    kernel = (1/16, 4/16, 6/16, 4/16, 1/16)
    h, w = a.shape
    p = np.pad(a, ((0, 0), (2, 2)), mode='reflect')
    tmp = sum(k*p[:, i:i+w] for i, k in enumerate(kernel))
    p = np.pad(tmp, ((2, 2), (0, 0)), mode='reflect')
    return sum(k*p[i:i+h, :] for i, k in enumerate(kernel))[::2, ::2].copy()


def pyramid(a, min_side=256):
    levels = [a]
    while max(levels[-1].shape) > min_side:
        levels.append(downsample(levels[-1]))
    return levels


def edges(a):
    gy, gx = np.gradient(a)
    return np.hypot(gx, gy).astype(np.float32)


def search(reference, moving, metric='ncc', center=(0, 0), radius=15,
           border=0.12, max_score_side=512):
    """Exhaustive integer search on a fixed interior ROI, without wraparound.

    Every candidate is evaluated on the SAME reference pixels. At high
    resolution, a regular grid limits scoring cost, but offsets remain integer
    pixels at the original level resolution. L2 squared / N is MSE, which has
    the same minimizer as L2 on this fixed-size support. NCC matches the
    assignment's uncentered normalized dot product.
    """
    if metric not in ('ncc', 'l2'):
        raise ValueError('metric must be ncc or l2')
    h, w = reference.shape
    if moving.shape != reference.shape:
        raise ValueError('channel shapes must match')
    cx, cy = center
    mx = max(int(w*border), abs(cx)+radius+1)
    my = max(int(h*border), abs(cy)+radius+1)
    if 2*mx >= w or 2*my >= h:
        raise ValueError('search window leaves no valid interior')
    step = max(1, math.ceil(max(h-2*my, w-2*mx)/max_score_side))
    ref = reference[my:h-my:step, mx:w-mx:step]
    refnorm = float(np.sum(ref*ref, dtype=np.float64))
    best_score, best = -float('inf'), center
    # Center-first tie order makes flat/ambiguous regions prefer less motion.
    candidates = [(dx,dy) for dy in range(cy-radius,cy+radius+1)
                  for dx in range(cx-radius,cx+radius+1)]
    candidates.sort(key=lambda p: (abs(p[0]-cx)+abs(p[1]-cy),p[1],p[0]))
    for dx, dy in candidates:
        mov = moving[my-dy:h-my-dy:step, mx-dx:w-mx-dx:step]
        if metric == 'l2':
            diff = ref-mov
            score = -float(np.mean(diff*diff, dtype=np.float64))
        else:
            denom = math.sqrt(refnorm*float(np.sum(mov*mov, dtype=np.float64)))
            score = float(np.sum(ref*mov, dtype=np.float64))/denom if denom > 1e-15 else 0.0
        if score > best_score + 1e-12:
            best_score, best = score, (dx,dy)
    return best, best_score, step


def align(reference, moving, metric='ncc', multiscale=True,
          feature='intensity', radius=15, refine_radius=2):
    refs = pyramid(reference) if multiscale else [reference]
    movs = pyramid(moving) if multiscale else [moving]
    shift, trace = (0,0), []
    for level in reversed(range(len(refs))):
        if level < len(refs)-1:
            shift = (2*shift[0], 2*shift[1])
        r = radius if level == len(refs)-1 else refine_radius
        a,b = refs[level],movs[level]
        if feature == 'edges': a,b = edges(a),edges(b)
        shift, score, step = search(a,b,metric,shift,r)
        trace.append({'level':level, 'shape':list(a.shape), 'shift':list(shift),
                      'score':score, 'sampling_step':step, 'radius':r})
    return shift,trace


def compose(channels, green=(0,0), red=(0,0), crop_overlap=True):
    b,g,r = channels
    dxg,dyg = green; dxr,dyr = red
    rgb = np.stack((np.roll(r,(dyr,dxr),(0,1)),
                    np.roll(g,(dyg,dxg),(0,1)), b),axis=-1)
    h,w = b.shape
    box = (max(0,dxg,dxr),max(0,dyg,dyr),
           min(w,w+dxg,w+dxr),min(h,h+dyg,h+dyr))
    if crop_overlap:
        x0,y0,x1,y1=box
        rgb=rgb[y0:y1,x0:x1]
    return rgb,box


def detect_crop(rgb, max_fraction=0.12):
    """Detect damaged edge bands from intensity and channel disagreement.

    Valid-overlap cropping happens before this function. This second stage
    uses image evidence, not a fixed trim. Examine outer 12% for rows/columns
    dominated by near-black, near-white, or atypical color disagreement;
    stop before removing more than 12% from any side. Conservative by design.
    """
    h,w=rgb.shape[:2]
    sample=rgb[::max(1,h//700),::max(1,w//700)]
    sh,sw=sample.shape[:2]
    core=sample[sh//5:4*sh//5,sw//5:4*sw//5]
    spread=np.ptp(sample,axis=2)
    threshold=max(0.22,float(np.quantile(np.ptp(core,axis=2),.90))*1.5)
    bad=(np.max(sample,axis=2)<.06)|(np.min(sample,axis=2)>.96)|(spread>min(threshold,.35))
    def bounds(profile,n):
        # Restrict search to boundary bands; require a majority of bad pixels.
        k=max(1,int(n*max_fraction))
        left=np.where(profile[:k]>.48)[0]
        right=np.where(profile[n-k:]>.48)[0]
        lo=int(left[-1]+1) if len(left) else 0
        hi=int(n-k+right[0]) if len(right) else n
        return lo,hi
    y0,y1=bounds(bad.mean(axis=1),sh)
    x0,x1=bounds(bad.mean(axis=0),sw)
    box=(int(x0*w/sw),int(y0*h/sh),int(x1*w/sw),int(y1*h/sh))
    x0,y0,x1,y1=box
    return rgb[y0:y1,x0:x1],box


def white_balance(rgb):
    """Damped gray-world gains estimated from nonsaturated central pixels.

    Only 35% of the estimated correction is applied: natural scenes are not
    necessarily gray, and unrestricted gray-world can produce severe casts.
    """
    h,w=rgb.shape[:2]
    s=rgb[h//10:9*h//10:max(1,h//500),w//10:9*w//10:max(1,w//500)]
    valid=(s.min(axis=2)>.05)&(s.max(axis=2)<.95)
    pixels=s[valid] if valid.any() else s.reshape(-1,3)
    means=np.mean(pixels,axis=0,dtype=np.float64)
    gains=1+.35*(np.clip(np.mean(means)/np.maximum(means,1e-6),.8,1.25)-1)
    return np.clip(rgb*gains.astype(np.float32),0,1),gains.tolist()


def contrast(rgb):
    """One global 1st/99th-percentile stretch uses the same map for R, G, B."""
    h,w=rgb.shape[:2]
    lo,hi=np.quantile(rgb[::max(1,h//700),::max(1,w//700)],(.01,.99))
    if hi-lo<1e-6:return rgb.copy(),[float(lo),float(hi)]
    return np.clip((rgb-lo)/(hi-lo),0,1),[float(lo),float(hi)]


def save_image(path,rgb,max_side=None,quality=92):
    im=Image.fromarray(np.uint8(np.clip(rgb,0,1)*255+.5))
    if max_side:im.thumbnail((max_side,max_side),Image.Resampling.LANCZOS)
    im.save(path,quality=quality)
