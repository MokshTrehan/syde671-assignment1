"""Optional local-translation diagnostic and affine displacement experiment.

No registration library is used. Coordinates are in the blue reference frame.
The inverse sampling map is q = p - d(p), where d is constant or affine.
"""
import numpy as np


def ncc(a,b):
    den=np.sqrt(np.sum(a*a,dtype=np.float64)*np.sum(b*b,dtype=np.float64))
    return float(np.sum(a*b,dtype=np.float64)/den) if den>1e-15 else 0.


def bilinear(a,x,y):
    """Sample valid coordinates; raise rather than silently wrap or extrapolate."""
    h,w=a.shape
    if np.any(x<0) or np.any(x>w-1) or np.any(y<0) or np.any(y>h-1):
        raise ValueError('sampling coordinates leave the input')
    ix=np.floor(x).astype(np.int32);iy=np.floor(y).astype(np.int32)
    jx=np.minimum(ix+1,w-1);jy=np.minimum(iy+1,h-1)
    fx=x-ix;fy=y-iy
    return ((1-fx)*(1-fy)*a[iy,ix]+fx*(1-fy)*a[iy,jx]
            +(1-fx)*fy*a[jy,ix]+fx*fy*a[jy,jx]).astype(np.float32)


def design(x,y,shape):
    h,w=shape
    return np.stack((np.ones_like(x),x/(w-1)-.5,y/(h-1)-.5),axis=-1)


def displacement(coeff,x,y,shape):
    return design(x,y,shape)@np.asarray(coeff)


def local_match(reference,moving,box,initial,radius=8):
    """Full-pixel local NCC with fixed support and a bounded subpixel fit."""
    x0,y0,x1,y1=box;a=reference[y0:y1,x0:x1]
    cx,cy=(int(round(v)) for v in initial)
    def score(dx,dy):return ncc(a,moving[y0-dy:y1-dy,x0-dx:x1-dx])
    candidates=[(dx,dy) for dy in range(cy-radius,cy+radius+1) for dx in range(cx-radius,cx+radius+1)]
    candidates.sort(key=lambda s:(abs(s[0]-cx)+abs(s[1]-cy),s[1],s[0]))
    scores=[score(*s) for s in candidates];i=int(np.argmax(scores));dx,dy=candidates[i]
    boundary=abs(dx-cx)==radius or abs(dy-cy)==radius
    ds=[]
    for axis in (0,1):
        sm=score(dx-int(axis==0),dy-int(axis==1));sp=score(dx+int(axis==0),dy+int(axis==1))
        curvature=sm-2*scores[i]+sp
        ds.append(float(np.clip(.5*(sm-sp)/curvature,-.5,.5)) if curvature < -1e-10 else 0.)
    return {'shift':[dx+ds[0],dy+ds[1]],'integer_shift':[dx,dy],
            'ncc':scores[i],'boundary':boundary,'reference_std':float(a.std()),
            'usable':not boundary and scores[i]>=.25 and float(a.std())>=1e-5}


def fit_field(positions,shifts,shape,affine=True):
    """Huber IRLS on local shifts; one radial weight for each 2-D residual."""
    xy=np.asarray(positions,float);target=np.asarray(shifts,float)
    X=design(xy[:,0],xy[:,1],shape)
    if not affine:X=X[:,:1]
    if len(X)<(6 if affine else 3) or np.linalg.matrix_rank(X)<X.shape[1]:
        raise ValueError('insufficient independent matches')
    weights=np.ones(len(X))
    for _ in range(10):
        root=np.sqrt(weights)[:,None]
        coef=np.linalg.lstsq(X*root,target*root,rcond=None)[0]
        distance=np.linalg.norm(X@coef-target,axis=1)
        weights=np.minimum(1.,1.0/np.maximum(distance,1e-12))
    if not affine:coef=np.vstack((coef,np.zeros((2,2))))
    return coef


def score_box(reference,moving,box,coeff):
    x0,y0,x1,y1=box;yy,xx=np.mgrid[y0:y1,x0:x1].astype(np.float64)
    d=displacement(coeff,xx,yy,reference.shape)
    return ncc(reference[y0:y1,x0:x1],bilinear(moving,xx-d[:,:,0],yy-d[:,:,1]))


def affine_matrix(coeff,shape):
    """Return the 2x3 reference-to-moving sampling matrix (not forward warp)."""
    h,w=shape;c=np.asarray(coeff)
    return np.array([[1-c[1,0]/(w-1),-c[2,0]/(h-1),-c[0,0]+.5*(c[1,0]+c[2,0])],
                     [-c[1,1]/(w-1),1-c[2,1]/(h-1),-c[0,1]+.5*(c[1,1]+c[2,1])]])


def safe_box(shape,coeffs):
    """Conservative rectangle guaranteed valid for every affine map.

    Affine displacement extrema occur at reference-image corners. Bounds based
    on those extrema may crop a few additional pixels but never extrapolate.
    """
    h,w=shape;x=np.array([0,w-1,0,w-1]);y=np.array([0,0,h-1,h-1])
    ds=np.concatenate([displacement(c,x,y,shape) for c in coeffs])
    x0=max(0,int(np.ceil(ds[:,0].max())));y0=max(0,int(np.ceil(ds[:,1].max())))
    x1=min(w,int(np.floor(w-1+ds[:,0].min()))+1);y1=min(h,int(np.floor(h-1+ds[:,1].min()))+1)
    if x0>=x1 or y0>=y1:raise ValueError('no valid affine overlap')
    return (x0,y0,x1,y1)


def compose_affine(channels,green,red,box=None):
    """Render original intensities once, in row blocks, with bilinear sampling."""
    b,g,r=channels;h,w=b.shape
    if box is None:box=safe_box(b.shape,[green,red,np.zeros((3,2))])
    x0,y0,x1,y1=box;out=np.empty((y1-y0,x1-x0,3),np.float32)
    for start in range(y0,y1,128):
        end=min(y1,start+128);yy,xx=np.mgrid[start:end,x0:x1].astype(np.float64)
        for k,a,c in [(0,r,red),(1,g,green)]:
            d=displacement(c,xx,yy,(h,w));out[start-y0:end-y0,:,k]=bilinear(a,xx-d[:,:,0],yy-d[:,:,1])
        out[start-y0:end-y0,:,2]=b[start:end,x0:x1]
    return out,box
