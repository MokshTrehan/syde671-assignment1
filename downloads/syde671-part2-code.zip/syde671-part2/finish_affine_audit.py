"""Render the audit-selected optional results and reproducible inspection crops.

Run after audit_affine.py. Neither required results nor existing enhancement
images are overwritten. Rejected channel fits retain their original translation.
"""
from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from src.alignment import read_plate,save_image
from src.affine_audit import compose_affine
ROOT=Path(__file__).resolve().parent
# Display locations are for inspection only; none changes fitting or acceptance.
DISPLAY_REGIONS={'01047u':[(.50,.35,'Embossed border and inset portrait'),(.35,.50,'Metal rays and vertical border'),(.80,.65,'Chain and curved vessel')],
                 '01007a':[(.35,.50,'People, posts and tree line'),(.50,.65,'Central timber joints'),(.80,.65,'Right-hand timber and textiles')]}

def main():
    path=ROOT/'results/affine-audit/audit.json';audit=json.loads(path.read_text());base={r['id']:r for r in json.loads((ROOT/'results/metrics.json').read_text())}
    dest=ROOT/'site/dist/images';out=ROOT/'results/affine-audit'
    for rec in audit['images']:
        stem=rec['id'];selected=[];selected_names=[]
        for name in ['green','red']:
            channel=rec['channels'][name]
            c=np.zeros((3,2));c[0]=base[stem]['methods']['refined_edges_ncc'][name]
            if channel['accepted']:c=np.array(channel['affine_coefficients']);selected_names.append(name)
            selected.append(c)
        rec['selected_affine_channels']=selected_names
        if not selected_names:continue
        rgb,box=compose_affine(read_plate(ROOT/'data/provided'/f'{stem}.jpg'),*selected)
        save_image(out/f'{stem}-selected.jpg',rgb)
        save_image(dest/f'{stem}-affine-selected.jpg',rgb,1200)
        rec['selected_overlap_box']=list(box);rec['selected_coefficients']=[c.tolist() for c in selected]
        h,w=rec['shape'];rec['display_regions']=[]
        for i,(fx,fy,label) in enumerate(DISPLAY_REGIONS[stem]):
            side=384;x0=int(fx*(w-1))-side//2;y0=int(fy*(h-1))-side//2
            cropbox=[x0,y0,x0+side,y0+side]
            rec['display_regions'].append({'index':i+1,'label':label,'blue_reference_box':cropbox})
            for key,p,b in [('translation',ROOT/f'results/{stem}/refined_edges_ncc.jpg',base[stem]['methods']['refined_edges_ncc']['overlap_box']),
                            ('candidate',out/f'{stem}-affine.jpg',rec['affine_overlap_box']),
                            ('selected',out/f'{stem}-selected.jpg',box)]:
                with Image.open(p) as im:
                    xy=(x0-b[0],y0-b[1],x0+side-b[0],y0+side-b[1]);assert min(xy[:2])>=0 and xy[2]<=im.width and xy[3]<=im.height
                    im.crop(xy).save(dest/f'{stem}-audit-{i+1}-{key}.jpg',quality=96)
        # Grid overlay in the blue-reference coordinate system of the preview.
        original=base[stem]['methods']['refined_edges_ncc']['overlap_box']
        with Image.open(ROOT/f'results/{stem}/refined_edges_ncc.jpg') as im:
            scale=1000/im.width;im=im.resize((1000,round(im.height*scale)))
            d=ImageDraw.Draw(im);font=ImageFont.load_default()
            for p in rec['channels']['green']['patches']:
                b=p['box'];xy=[(b[0]-original[0])*scale,(b[1]-original[1])*scale,(b[2]-original[0])*scale,(b[3]-original[1])*scale]
                color='#ffcc33' if p['split']=='fit' else '#31edff'
                d.rectangle(xy,outline=color,width=3)
                d.text((xy[0]+3,xy[1]+3),f'{p["row"]+1},{p["column"]+1}',font=font,fill=color,stroke_width=2,stroke_fill='black')
            im.save(dest/f'{stem}-audit-grid.jpg',quality=94)
    path.write_text(json.dumps(audit,indent=2)+'\n')
    downloads=ROOT/'site/dist/downloads';downloads.mkdir(parents=True,exist_ok=True)
    (downloads/'affine-audit.json').write_text(path.read_text())
    print('Selected affine channels:',{r['id']:r['selected_affine_channels'] for r in audit['images']})

if __name__=='__main__':main()
