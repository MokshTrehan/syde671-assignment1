// Export the exact static webpage to PDF and verify responsive rendering.
// npm install playwright; PLAYWRIGHT_CHROMIUM_EXECUTABLE=/path/to/chrome node export_report.cjs
const {chromium}=require('playwright');
const fs=require('fs');const path=require('path');
(async()=>{
 const root=__dirname;const out=path.join(root,'output');fs.mkdirSync(path.join(out,'qa'),{recursive:true});
 const browser=await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE||undefined});
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('file://'+path.join(root,'site/dist/index.html'),{waitUntil:'load'});
 await page.evaluate(async()=>{for(const i of document.images)i.loading='eager';await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})));await document.fonts.ready;});
 const desktop=await page.evaluate(()=>({title:document.title,width:innerWidth,scrollWidth:document.documentElement.scrollWidth,images:document.images.length,broken:[...document.images].filter(i=>!i.complete||!i.naturalWidth).map(i=>i.src)}));
 await page.screenshot({path:path.join(out,'qa/desktop.png')});
 await page.pdf({path:path.join(out,'pdf/syde671-part2-report.pdf'),format:'A4',printBackground:true,preferCSSPageSize:true,displayHeaderFooter:true,headerTemplate:'<div></div>',footerTemplate:'<div style="font-family:Arial;font-size:8px;color:#52647b;width:100%;padding:0 14mm;display:flex;justify-content:space-between"><span>SYDE 671 · Images of the Russian Empire</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>'});
 await page.setViewportSize({width:390,height:844});
 await page.screenshot({path:path.join(out,'qa/mobile.png')});
 const mobile=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth}));
 fs.writeFileSync(path.join(out,'qa/browser-checks.json'),JSON.stringify({desktop,mobile,errors},null,2));
 console.log(JSON.stringify({desktop,mobile,errors}));await browser.close();
 if(errors.length||desktop.broken.length||mobile.scrollWidth>mobile.width)process.exitCode=1;
})();
